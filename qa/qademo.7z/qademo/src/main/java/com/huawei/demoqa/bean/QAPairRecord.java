package com.huawei.demoqa.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class QAPairRecord implements Record{
    @JsonProperty("qa_pair_id")
    private String qaPairId;

    @JsonProperty("st_question")
    private String stQuestion;

    private List<String> rawExQuestions = null;

    @JsonProperty("ex_questions")
    private List<ExQuestionContent> exQuestions = null;

    private String answer;

    @JsonProperty("answer_compressed")
    private Boolean answerCompressed;

    private String link;

    private String domain;

    private String description;

    private List<String> relevance;

    @JsonProperty("updated_time")
    private String updatedTime;

    public String getQaPairId() {
        return qaPairId;
    }

    public void setQaPairId(String qaPairId) {
        this.qaPairId = qaPairId;
    }

    public String getStQuestion() {
        return stQuestion;
    }

    public void setStQuestion(String stQuestion) {
        this.stQuestion = stQuestion;
    }

    public List<String> getRawExQuestions() {
        return rawExQuestions;
    }

    public void setRawExQuestions(List<String> rawExQuestions) {
        this.rawExQuestions = rawExQuestions;
    }

    public List<ExQuestionContent> getExQuestions() {
        return exQuestions;
    }

    public void setExQuestions(List<ExQuestionContent> exQuestions) {
        this.exQuestions = exQuestions;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Boolean getAnswerCompressed() {
        return answerCompressed;
    }

    public void setAnswerCompressed(Boolean answerCompressed) {
        this.answerCompressed = answerCompressed;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getRelevance() {
        return relevance;
    }

    public void setRelevance(List<String> relevance) {
        this.relevance = relevance;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    @Override
    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }
}
