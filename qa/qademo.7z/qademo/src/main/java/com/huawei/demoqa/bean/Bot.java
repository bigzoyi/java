package com.huawei.demoqa.bean;

/**
 * bot
 */
public class Bot {
    private String botId;
    private String botName;
    private String projectId;
    private String startCommand;
    private String startAnswer;

    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public String getBotName() {
        return botName;
    }

    public void setBotName(String botName) {
        this.botName = botName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getStartCommand() {
        return startCommand;
    }

    public void setStartCommand(String startCommand) {
        this.startCommand = startCommand;
    }

    public String getStartAnswer() {
        return startAnswer;
    }

    public void setStartAnswer(String startAnswer) {
        this.startAnswer = startAnswer;
    }



    @Override
    public boolean equals(Object obj) {
        final Bot o1 = (Bot) obj;
        if(this.getStartCommand() != null) {
            return this.getStartCommand().equals(o1.getStartCommand());
        }
        return false;
    }
}
