package com.huawei.demoqa.bean.iam;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Identity extends HashMap<String, Object> {
    private Set<String> methods = new HashSet<>();

    /**
     * Identity
     */
    public Identity() {
        super();
    }

    /**
     * putIdentity
     *
     * @param identity identity
     */
    public void putIdentity(IdentityType identity) {
        putIdentity("password", identity);
    }

    /**
     * putIdentity
     *
     * @param method   method
     * @param identity identity
     */
    public void putIdentity(String method, IdentityType identity) {
        methods.add(method);
        this.put("methods", methods);
        this.put(method, identity);
    }

    public void clear() {
        methods.clear();
        super.clear();
    }
}
