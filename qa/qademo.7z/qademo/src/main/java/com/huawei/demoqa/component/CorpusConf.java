package com.huawei.demoqa.component;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "corpus")
public class CorpusConf {

    /**
     * 表情包问答语料
     */
    private Map<String, List<String>> emoticons;

    private List<String> emoticonDefault;

    public Map<String, List<String>> getEmoticons() {
        return emoticons;
    }

    public void setEmoticons(Map<String, List<String>> emoticons) {
        this.emoticons = emoticons;
    }

    public List<String> getEmoticonDefault() {
        return emoticonDefault;
    }

    public void setEmoticonDefault(List<String> emoticonDefault) {
        this.emoticonDefault = emoticonDefault;
    }
}
