package com.huawei.demoqa.bean.iam;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class AuthBuilder {
    public static String buildAuthJson(String userName, String pwd, String domainName, Object object) {
        User user = new User(userName, pwd, new User.Domain(domainName));
        Identity identity = new Identity();
        identity.putIdentity(new Password(user));
        Scope scope;
        if (object instanceof Scope.Project) {
            scope = new Scope((Scope.Project) object);
        } else {
            scope = new Scope((Scope.Domain) object);
        }

        Map<String, Auth> auth = new HashMap<>();
        auth.put("auth", new Auth(identity, scope));
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(auth);
        } catch (JsonProcessingException ignore) {
            return StringUtils.EMPTY;
        }
    }

    public static String buildAuthJson(String token, Object object) {
        final Identity identity = new Identity();
        identity.putIdentity("token", new Token(token));
        Scope scope;
        if(object instanceof Scope.Project){
            scope = new Scope((Scope.Project)object);
        } else {
            scope = new Scope((Scope.Domain) object);
        }

        Map<String, Auth> auth = new HashMap<>();
        auth.put("auth", new Auth(identity, scope));
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(auth);
        } catch (JsonProcessingException ignore) {
            return StringUtils.EMPTY;
        }
    }
}
