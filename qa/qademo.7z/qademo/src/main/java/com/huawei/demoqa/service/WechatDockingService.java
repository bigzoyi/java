package com.huawei.demoqa.service;

import com.huawei.demoqa.bean.Register;

public interface WechatDockingService {
    boolean docking(Register register);

    boolean isExist(String id);

    String getToken(String id);
}
