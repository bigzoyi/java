package com.huawei.demoqa.bean.iam;

public class Password extends IdentityType {
    private User user;

    public Password(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
