package com.huawei.demoqa.service;

import com.huawei.demoqa.bean.QasReq;

import java.io.IOException;

public interface WeChatEmoticonService {
    String chat(QasReq qasReq) throws IOException;
}