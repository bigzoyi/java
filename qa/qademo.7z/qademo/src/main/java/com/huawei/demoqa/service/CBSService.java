package com.huawei.demoqa.service;

import com.huawei.demoqa.bean.QasReq;

import java.io.IOException;

public interface CBSService {
    String chat(QasReq qasReq) throws IOException;
}
