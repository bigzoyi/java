package com.huawei.demoqa.bean;

public class ExQuestionContent {
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
