package com.huawei.demoqa.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class QAPairResult extends QAPairRecord{
    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("relevance_details")
    private List<RelevanceDetails> relevanceDetails = null;

    private Double score;

    @JsonProperty("top_score_ex_question")
    private String topExQuestion;

    @JsonProperty(value = "ex_question_terms")
    private List<String> exQuestionTerms;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public List<RelevanceDetails> getRelevanceDetails() {
        return relevanceDetails;
    }

    public void setRelevanceDetails(List<RelevanceDetails> relevanceDetails) {
        this.relevanceDetails = relevanceDetails;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public String getTopExQuestion() {
        return topExQuestion;
    }

    public void setTopExQuestion(String topExQuestion) {
        this.topExQuestion = topExQuestion;
    }

    public List<String> getExQuestionTerms() {
        return exQuestionTerms;
    }

    public void setExQuestionTerms(List<String> exQuestionTerms) {
        this.exQuestionTerms = exQuestionTerms;
    }
}
