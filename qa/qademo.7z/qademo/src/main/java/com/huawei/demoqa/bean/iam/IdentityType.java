package com.huawei.demoqa.bean.iam;

/**
 * IdentityType
 */
abstract class IdentityType {
}
