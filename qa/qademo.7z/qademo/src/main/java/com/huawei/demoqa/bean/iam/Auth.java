package com.huawei.demoqa.bean.iam;

/**
 * auth
 */
public class Auth {
    private Identity identity;

    private Scope scope;

    public Auth(Identity identity, Scope scope) {
        this.identity = identity;
        this.scope = scope;
    }

    public Identity getIdentity() {
        return identity;
    }

    public void setIdentity(Identity identity) {
        this.identity = identity;
    }

    public Scope getScope() {
        return scope;
    }

    public void setScope(Scope scope) {
        this.scope = scope;
    }
}
