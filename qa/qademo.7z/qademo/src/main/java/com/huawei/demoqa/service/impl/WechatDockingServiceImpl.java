package com.huawei.demoqa.service.impl;

import com.huawei.demoqa.bean.Register;
import com.huawei.demoqa.service.WechatDockingService;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class WechatDockingServiceImpl implements WechatDockingService {
    private Map<String, String> registry = new HashMap<>();

    @Override
    public boolean docking(Register register) {
        if (register != null && StringUtils.isEmpty(register.getToken())) {
            return false;
        }
        registry.put(register.getAppid(), register.getToken());
        return true;
    }

    @Override
    public boolean isExist(String id) {
        return registry.get(id) != null;
    }

    @Override
    public String getToken(String id) {
        return registry.get(id);
    }
}
