package com.huawei.demoqa.service;

import javax.servlet.http.HttpServletRequest;

public interface WeChatService {
    String processRequest(HttpServletRequest request);
}
