package com.huawei.demoqa.bean;

public class RelevanceDetails {
    private String question;

    private String link;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
