package com.huawei.demoqa.service;

import com.huawei.demoqa.bean.iam.AuthBuilder;
import com.huawei.demoqa.bean.iam.Scope;
import com.huawei.demoqa.common.OKHttpUtils;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

public class TokenManager {
    private static final Integer ONE_HOUR = 60 * 60 * 1000;
    private static final String IAM_TOKEN_KEY = "x-subject-token";
    private static ConcurrentHashMap<String, Token> tokenCheckMap = new ConcurrentHashMap<>();

    public static String getToken(String user, String pwd, String domain) throws IOException {
        if (tokenCheckMap.get(user) != null && !tokenCheckMap.get(user).isExpired()) {
            return tokenCheckMap.get(user).token;
        }

        String iam = "https://iam.cn-north-1.myhuaweicloud.com/v3/auth/tokens";
        String requestBody = AuthBuilder.buildAuthJson(user, pwd, domain, new Scope.Project("cn-north-1"));

        final Response response = OKHttpUtils.post(null, iam, requestBody);
        if (response.isSuccessful()) {
            final String tokenHeader = response.header(IAM_TOKEN_KEY);
            final Token token = new Token(tokenHeader, System.currentTimeMillis());
            tokenCheckMap.put(user, token);
            return tokenHeader;
        }
        throw new IOException("iam error");
    }

    private static class Token {
        private String token;

        private long createTime;

        public Token(String token, long createTime) {
            this.token = token;
            this.createTime = createTime;
        }

        boolean isExpired() {
            long now = System.currentTimeMillis();
            return now - createTime > 6 * ONE_HOUR;
        }
    }
}
