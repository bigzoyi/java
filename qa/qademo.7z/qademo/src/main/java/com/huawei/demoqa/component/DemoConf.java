package com.huawei.demoqa.component;

import com.huawei.demoqa.bean.Bot;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "democonf")
public class DemoConf {
    private List<Bot> bots;

    private String botDefault;

    private Bot defaultBot;

    public List<Bot> getBots() {
        return bots;
    }

    public void setBots(List<Bot> bots) {
        this.bots = bots;
    }

    public String getBotDefault() {
        return botDefault;
    }

    public void setBotDefault(String botDefault) {
        this.botDefault = botDefault;
    }

    public Bot startBot(String question) {
        for (Bot bot : bots) {
            if (question.equals(bot.getStartCommand())) {
                return bot;
            }
        }
        return null;
    }

    public Bot getDefaultBot() {
        if (defaultBot == null) {
            for (Bot bot : bots) {
                if (botDefault.equals(bot.getBotId())) {
                    defaultBot = bot;
                }
            }
        }
        return defaultBot;
    }
}
