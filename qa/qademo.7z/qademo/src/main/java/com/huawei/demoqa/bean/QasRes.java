package com.huawei.demoqa.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class QasRes {
    private String question;

    @JsonProperty("request_id")
    private String requestId;

    private List<QAPairResult> answers;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public List<QAPairResult> getAnswers() {
        return answers;
    }

    public void setAnswers(List<QAPairResult> answers) {
        this.answers = answers;
    }
}
