package com.huawei.demoqa.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public interface Record {
    @JsonIgnore
    default String getId() {
        return null;
    }

    default void setUpdatedTime(String updatedTime) {

    }

    @JsonIgnore
    default String getIndex() {
        return null;
    }
}
