package com.huawei.demoqa.common;

import okhttp3.*;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

public class OKHttpUtils {
    private static OkHttpClient client = new OkHttpClient.Builder().build();

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    public static Response get(Map<String, String> headers, String url) throws IOException {
        final Request.Builder builder = getBuilder(headers, url);

        final Request request = builder.build();
        return client.newCall(request).execute();
    }

    public static Response post(Map<String, String> headers, String url, String json) throws IOException {
        final Request.Builder builder = getBuilder(headers, url);
        final RequestBody body = RequestBody.create(JSON, json);
        final Request request = builder.post(body).build();
        return client.newCall(request).execute();
    }

    private static Request.Builder getBuilder(Map<String, String> headers, String url) {
        final Request.Builder builder = new Request.Builder();
        setHeaders(headers, builder);
        builder.url(url);
        return builder;
    }

    private static void setHeaders(Map<String, String> headers, Request.Builder builder) {
        if (!CollectionUtils.isEmpty(headers)) {
            final Iterator<Map.Entry<String, String>> iterator = headers.entrySet().iterator();
            while (iterator.hasNext()) {
                final Map.Entry<String, String> entry = iterator.next();
                builder.addHeader(entry.getKey(), entry.getValue());
            }
        }
    }
}
