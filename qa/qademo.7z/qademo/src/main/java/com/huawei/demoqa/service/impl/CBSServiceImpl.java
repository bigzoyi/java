package com.huawei.demoqa.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.huawei.demoqa.bean.Bot;
import com.huawei.demoqa.bean.QasReq;
import com.huawei.demoqa.bean.QasRes;
import com.huawei.demoqa.common.OKHttpUtils;
import com.huawei.demoqa.component.DemoConf;
import com.huawei.demoqa.service.CBSService;
import com.huawei.demoqa.service.TokenManager;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Service
public class CBSServiceImpl implements CBSService {

    Map<String, Bot> userBotMap = new HashMap<>();

    @Autowired
    private DemoConf demoConf;

    @Override
    public String chat(QasReq qasReq) throws IOException {
        final Bot startBot = demoConf.startBot(qasReq.getQuestion());

        Bot bot = userBotMap.get(qasReq.getSessionId());
        if (startBot == null) {
            if (bot == null) {
                bot = demoConf.getDefaultBot();
                userBotMap.put(qasReq.getSessionId(), bot);
            }

            String url = String.format("https://cbs-ext.cn-north-1.myhuaweicloud.com/v1/%s/qabots/%s/requests",
                    bot.getProjectId(),
                    bot.getBotId());
            final String token = TokenManager.getToken("CLOUDBU_TIHZ_NLP", "WLcbForNlp@Huawei.76639", "hwstaff_pub_CTOTI");
            Map<String, String> headers = new HashMap<>();
            headers.put("X-Auth-Token", token);
            final ObjectMapper mapper = new ObjectMapper();
            final Response response = OKHttpUtils.post(headers, url, mapper.writeValueAsString(qasReq));
            if (response.isSuccessful()) {
                final QasRes qasRes = mapper.readValue(response.body().string(), QasRes.class);
                if (qasRes != null && !CollectionUtils.isEmpty(qasRes.getAnswers())) {
                    return qasRes.getAnswers().get(0).getAnswer();
                }
            }
            return null;
        } else {
            if (bot == null || !bot.getBotId().equals(startBot.getBotId())) {
                userBotMap.put(qasReq.getSessionId(), startBot);
            }
            return startBot.getStartAnswer();
        }
    }
}