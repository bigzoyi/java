package com.huawei.demoqa.service.impl;

import com.huawei.demoqa.bean.QasReq;
import com.huawei.demoqa.component.CorpusConf;
import com.huawei.demoqa.service.WeChatEmoticonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Service
public class WeChatEmoticonServiceImpl implements WeChatEmoticonService {

    @Autowired
    private CorpusConf corpusConf;

    Random random = new Random();

    @Override
    public String chat(QasReq qasReq) throws IOException {
        final Map<String, List<String>> emoticons = corpusConf.getEmoticons();
        final List<String> answers = emoticons.get(qasReq.getQuestion().trim());

        if (!CollectionUtils.isEmpty(answers)) {
            return answers.get(random.nextInt(answers.size()));
        }

        return corpusConf.getEmoticonDefault().get(random.nextInt(corpusConf.getEmoticonDefault().size()));
    }
}
